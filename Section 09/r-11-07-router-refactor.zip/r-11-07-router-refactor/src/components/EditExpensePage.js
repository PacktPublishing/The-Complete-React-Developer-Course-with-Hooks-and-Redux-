import React from 'react';

const EditExpensePage = () => (
  <div>
    This is from my edit expense component
  </div>
);

export default EditExpensePage;
